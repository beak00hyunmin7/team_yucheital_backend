"""Replaceable analysis-model adapters."""
