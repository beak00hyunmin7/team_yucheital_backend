# 학습 모델 연결 계약

`AI_MODEL_FACTORY`가 가리키는 팩토리는 `app.ai.interface.DrainageAIModel` 계약을
구현한 객체를 반환해야 합니다.

## `predict`

- 입력: 전처리된 `float32 [H, W]` 이미지, 입력 유형, 스케일·좌표계, 요청 배수구 수
- 출력: `PredictionOutput`
- `drainage_map` 값 범위: `0~1`
- `drains`: 요청된 개수와 동일하며 좌표는 normalized `0~1`

## `evaluate`

- 입력: 동일 지형, 사용자 배수구, 기본 예측 결과, 강우 등 파라미터
- 출력: `ScenarioOutput`
- 결과 맵과 지표는 학습된 시나리오 모델이 계산해야 합니다.

모델이 출력 계약을 어기면 API는 `AI_INFERENCE_FAILED` 또는
`SCENARIO_INFERENCE_FAILED`를 반환하고 결과를 저장하지 않습니다.

