# 학습 AI 기반 배수 분석 구조

## 온라인 처리

```mermaid
flowchart TD
    U["지형 이미지 업로드"] --> P["전처리·품질검사"]
    P --> S["terrain_uploads 저장"]
    S --> AI["학습 AI predict"]
    AI --> B["기본 배수맵·AI 배수구"]
    B --> R["drainage_results 저장"]
    R --> UI["프론트엔드 표시·배수구 수정"]
    UI --> E["학습 시나리오 모델 evaluate"]
    E --> C["기본안·사용자안 비교"]
    C --> R
```

## 역할 경계

| 구성 | 담당 역할 |
|---|---|
| FastAPI | 입력 검증, 전처리, 모델 호출, 출력 계약 검사, 캐시, 저장, 반환 |
| 학습 AI `predict` | 배수맵과 배수구 위치·지표 예측 |
| 학습 AI `evaluate` | 사용자 배수구 설정을 반영한 맵·지표 예측 |
| MySQL | 업로드·결과·좌표·버전·처리로그 메타데이터 |
| 파일 저장소 | 원본, preview, 배수맵, overlay, float 배열 |

FastAPI는 물리 규칙이나 지형 점수를 이용해 배수구를 자체 생성하지 않습니다. 모델이
연결되지 않거나 출력 계약을 지키지 않으면 오류를 반환합니다.

## 결과 관계

```mermaid
erDiagram
    TERRAIN_UPLOADS ||--o{ DRAINAGE_RESULTS : produces
    MODEL_VERSIONS ||--o{ DRAINAGE_RESULTS : predicts
    DRAINAGE_RESULTS ||--o{ RESULT_DRAINS : contains
    DRAINAGE_RESULTS ||--o{ RESULT_ARTIFACTS : owns
    DRAINAGE_RESULTS ||--o{ DRAINAGE_RESULTS : compares
```

`BASELINE` 결과는 학습 AI의 최초 예측이고, `SCENARIO` 결과는 사용자가 설정한 배수구를
시나리오 모델에 입력한 결과입니다. `parent_result_id`로 두 결과를 연결합니다.

