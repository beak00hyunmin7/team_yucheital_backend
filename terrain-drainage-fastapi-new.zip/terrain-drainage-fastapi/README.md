# 등고선·지형 학습 AI 배수 분석 백엔드

사용자가 등고선·지형 이미지를 업로드하면 **학습된 AI 모델**을 호출하여 배수맵과
배수구 위치를 예측하고, 사용자가 수정한 배수구 시나리오의 결과를 다시 AI로 평가하는
`FastAPI + MySQL` 백엔드입니다.

이 프로젝트에는 D8, 저지대 점수, 함몰 점수 등으로 배수구 위치를 자체 생성하는
대체 알고리즘이 없습니다. 학습 모델이 연결되지 않은 상태에서 예측 API를 호출하면
`503 MODEL_NOT_CONFIGURED`를 반환하며 임의 결과를 만들지 않습니다.

## 처리 흐름

```text
등고선·지형 이미지 업로드
→ 파일 검증·리사이즈·정규화·품질검사
→ 학습된 AI의 기본 배수맵·배수구 위치 예측
→ 결과 이미지·좌표·모델 버전·지표 저장
→ 사용자가 배수구 추가·이동·삭제
→ 학습된 시나리오 모델로 변경 결과 평가
→ 기본안과 사용자안 지표 비교
```

FastAPI의 역할은 요청 검증, 학습 모델 호출, 출력 형식 검증, 캐시, 시각화, DB·파일
저장과 결과 반환입니다. FastAPI가 배수구 위치를 판단하지 않습니다.

## API

| 기능 | API |
|---|---|
| 이미지 업로드·품질검사 | `POST /api/upload-terrain` |
| 학습 AI 기본 예측 | `POST /api/predict-drainage-map` |
| 사용자 배수구 시나리오 평가 | `POST /api/evaluate-drain-settings` |
| 저장 결과 조회 | `GET /api/result/{result_id}` |
| 서버·DB·모델 설정 상태 | `GET /health` |
| Swagger | `GET /docs` |

### 1. 업로드

`multipart/form-data` 필드:

| 필드 | 설명 |
|---|---|
| `file` | PNG/JPEG/WEBP/TIFF 이미지 |
| `input_type` | `contour`, `terrain`, `heightmap`, `dem` |
| `scale_m_per_pixel` | 선택, 픽셀당 실제 길이(m) |
| `coordinate_system` | 선택, 좌표계 이름 |

업로드 단계는 AI 모델이 없어도 사용할 수 있습니다.

```bash
curl -X POST "http://127.0.0.1:8000/api/upload-terrain" \
  -F "file=@samples/sample_dem.png" \
  -F "input_type=dem" \
  -F "scale_m_per_pixel=0.5" \
  -F "coordinate_system=LOCAL"
```

응답의 `upload_id`를 이후 요청에 사용합니다.

### 2. 기본 배수맵·배수구 AI 예측

```json
{
  "upload_id": "업로드_ID",
  "drain_count": 3,
  "rainfall_mm_per_hour": 50,
  "duration_minutes": 60,
  "runoff_coefficient": 0.8,
  "custom_parameters": {}
}
```

학습 AI는 다음을 직접 반환해야 합니다.

- `drainage_map`: `float32 [H, W]`, 값 범위 `0~1`
- 요청 개수와 동일한 AI 예측 배수구 normalized 좌표
- 모델이 정의한 요약 지표
- 선택적으로 전체 신뢰도와 경고

백엔드는 AI가 반환한 좌표를 변경하거나 자체 후보로 교체하지 않습니다.

### 3. 사용자 배수구 시나리오 평가

```json
{
  "upload_id": "업로드_ID",
  "baseline_result_id": "기본_예측_결과_ID",
  "drains": [
    {
      "id": "D-1",
      "x": 0.45,
      "y": 0.62,
      "coordinate_mode": "normalized",
      "drain_type": "grate",
      "capacity_lps": 80
    }
  ],
  "rainfall_mm_per_hour": 50,
  "duration_minutes": 60,
  "runoff_coefficient": 0.8,
  "custom_parameters": {}
}
```

사용자 설정은 학습된 시나리오 모델의 `evaluate` 메서드로 전달됩니다. 거리·용량 기반
규칙으로 결과를 임의 계산하지 않습니다.

## 학습 AI 연결

환경변수에 모델 팩토리를 지정합니다.

```env
AI_MODEL_FACTORY=my_ai.runtime:create_model
```

`create_model()`은 인자 없이 모델 객체를 반환해야 하며, 모델 객체는 다음 항목을
구현해야 합니다.

```python
version: str
name: str
predict(terrain, *, drain_count, parameters) -> PredictionOutput
evaluate(terrain, *, drains, baseline, parameters) -> ScenarioOutput
```

정확한 자료형은 `app/ai/interface.py`에 있습니다. PyTorch, ONNX 또는 별도 추론
서비스 연결은 이 팩토리 내부에서 구현합니다. 실제 학습 모델 파일이나 추론 코드는
사용자가 제공해야 하며, 이 백엔드는 대체 예측값을 생성하지 않습니다.

## 저장 구조

| 테이블 | 저장 내용 |
|---|---|
| `model_versions` | 실제 사용한 학습 모델 이름·버전 |
| `terrain_uploads` | 업로드, 스케일·좌표계, 품질검사, 전처리 버전 |
| `drainage_results` | 기본/사용자 시나리오 결과, 지표, 캐시, 처리시간 |
| `result_drains` | AI 예측 또는 사용자 설정 배수구 좌표·속성 |
| `result_artifacts` | 배수맵 PNG, overlay PNG, 원본 float 배열 경로 |
| `processing_runs` | 요청 단계, 지연시간, 캐시, 오류 코드 |

온라인 결과를 자동으로 AI 학습 정답으로 등록하지 않습니다. 학습 데이터는 CFD 또는
별도로 검증된 정답 데이터 파이프라인에서 관리해야 합니다.

기존 MySQL volume이 있어도 애플리케이션 시작 시 새 테이블이 추가됩니다. 이전 버전의
분석 테이블은 삭제하지 않으며 새 API에서 사용하지 않습니다.

MySQL Workbench에서 새 API의 저장 결과를 확인할 때는 다음 SQL을 사용합니다.

```sql
USE terrain_drainage;

SELECT
    r.id AS result_id,
    u.original_filename,
    r.result_type,
    r.status,
    r.model_version,
    r.created_at
FROM drainage_results AS r
JOIN terrain_uploads AS u ON u.id = r.upload_id
ORDER BY r.created_at DESC;
```

아직 예측된 결과가 없으면 열 이름은 표시되고 데이터 행만 비어 있습니다. 업로드만 한
상태는 `terrain_uploads` 테이블에서 확인할 수 있습니다.

## Docker 실행

```bash
cp .env.example .env
docker compose up --build
```

Windows 명령 프롬프트:

```bat
copy .env.example .env
run_windows.bat
```

- FastAPI: <http://127.0.0.1:8000/docs>
- MySQL Workbench: `127.0.0.1:13307`
- DB 사용자/비밀번호 기본값: `terrain` / `terrain`
- 스키마: `terrain_drainage`

운영 환경에서는 반드시 비밀번호와 CORS 허용 도메인을 변경해야 합니다.

## 테스트

```bash
python -m pip install -r requirements-dev.txt
python -m pytest
```

테스트에서만 가짜 학습 모델을 주입하여 API 계약과 저장 흐름을 확인합니다. 운영 코드에는
가짜 모델이나 규칙 기반 배수구 탐색기가 포함되지 않습니다.
