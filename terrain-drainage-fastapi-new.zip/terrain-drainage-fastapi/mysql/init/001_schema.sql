CREATE DATABASE IF NOT EXISTS terrain_drainage
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE terrain_drainage;

CREATE TABLE IF NOT EXISTS model_versions (
  version VARCHAR(80) PRIMARY KEY,
  name VARCHAR(200) NOT NULL,
  model_path VARCHAR(500) NULL,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS terrain_uploads (
  id CHAR(36) PRIMARY KEY,
  request_id CHAR(36) NOT NULL,
  image_hash CHAR(64) NOT NULL,
  original_filename VARCHAR(255) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  input_type VARCHAR(30) NOT NULL,
  original_width INT NOT NULL,
  original_height INT NOT NULL,
  analysis_width INT NOT NULL,
  analysis_height INT NOT NULL,
  scale_m_per_pixel DOUBLE NULL,
  coordinate_system VARCHAR(100) NULL,
  quality_score DOUBLE NOT NULL,
  quality_status VARCHAR(30) NOT NULL,
  quality_details_json JSON NOT NULL,
  preprocessing_version VARCHAR(80) NOT NULL,
  original_path VARCHAR(500) NOT NULL,
  preview_path VARCHAR(500) NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT uq_terrain_upload_request UNIQUE (request_id),
  INDEX ix_terrain_upload_hash (image_hash),
  INDEX ix_terrain_upload_quality_status (quality_status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS drainage_results (
  id CHAR(36) PRIMARY KEY,
  request_id CHAR(36) NOT NULL,
  upload_id CHAR(36) NOT NULL,
  parent_result_id CHAR(36) NULL,
  cache_key CHAR(64) NOT NULL,
  result_type VARCHAR(30) NOT NULL,
  status VARCHAR(30) NOT NULL,
  model_version VARCHAR(80) NOT NULL,
  preprocessing_version VARCHAR(80) NOT NULL,
  parameters_json JSON NOT NULL,
  metrics_json JSON NOT NULL,
  delta_metrics_json JSON NULL,
  warnings_json JSON NOT NULL,
  confidence DOUBLE NULL,
  processing_time_ms INT NOT NULL,
  error_message TEXT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT uq_drainage_result_request UNIQUE (request_id),
  CONSTRAINT fk_drainage_result_upload
    FOREIGN KEY (upload_id) REFERENCES terrain_uploads(id) ON DELETE CASCADE,
  CONSTRAINT fk_drainage_result_parent
    FOREIGN KEY (parent_result_id) REFERENCES drainage_results(id) ON DELETE SET NULL,
  CONSTRAINT fk_drainage_result_model
    FOREIGN KEY (model_version) REFERENCES model_versions(version),
  INDEX ix_drainage_result_upload (upload_id),
  INDEX ix_drainage_result_parent (parent_result_id),
  INDEX ix_drainage_result_cache (cache_key),
  INDEX ix_drainage_result_type (result_type),
  INDEX ix_drainage_result_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS result_drains (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  result_id CHAR(36) NOT NULL,
  drain_order INT NOT NULL,
  client_drain_id VARCHAR(80) NOT NULL,
  x_normalized DOUBLE NOT NULL,
  y_normalized DOUBLE NOT NULL,
  x_pixel INT NOT NULL,
  y_pixel INT NOT NULL,
  drain_type VARCHAR(80) NULL,
  capacity_lps DOUBLE NULL,
  diameter_mm DOUBLE NULL,
  discharge_coefficient DOUBLE NULL,
  confidence DOUBLE NULL,
  source VARCHAR(30) NOT NULL,
  payload_json JSON NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_result_drain_result
    FOREIGN KEY (result_id) REFERENCES drainage_results(id) ON DELETE CASCADE,
  INDEX ix_result_drain_result (result_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS result_artifacts (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  result_id CHAR(36) NOT NULL,
  kind VARCHAR(40) NOT NULL,
  storage_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_hash CHAR(64) NOT NULL,
  width INT NOT NULL,
  height INT NOT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_result_artifact_result
    FOREIGN KEY (result_id) REFERENCES drainage_results(id) ON DELETE CASCADE,
  INDEX ix_result_artifact_result (result_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS processing_runs (
  id BIGINT AUTO_INCREMENT PRIMARY KEY,
  request_id CHAR(36) NOT NULL,
  upload_id CHAR(36) NULL,
  result_id CHAR(36) NULL,
  stage VARCHAR(40) NOT NULL,
  status VARCHAR(30) NOT NULL,
  model_version VARCHAR(80) NULL,
  preprocessing_version VARCHAR(80) NOT NULL,
  latency_ms INT NOT NULL,
  cache_hit BOOLEAN NOT NULL DEFAULT FALSE,
  error_code VARCHAR(80) NULL,
  error_message TEXT NULL,
  created_at DATETIME(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  CONSTRAINT fk_processing_run_upload
    FOREIGN KEY (upload_id) REFERENCES terrain_uploads(id) ON DELETE SET NULL,
  CONSTRAINT fk_processing_run_result
    FOREIGN KEY (result_id) REFERENCES drainage_results(id) ON DELETE SET NULL,
  INDEX ix_processing_run_request (request_id),
  INDEX ix_processing_run_upload (upload_id),
  INDEX ix_processing_run_result (result_id),
  INDEX ix_processing_run_stage (stage),
  INDEX ix_processing_run_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

