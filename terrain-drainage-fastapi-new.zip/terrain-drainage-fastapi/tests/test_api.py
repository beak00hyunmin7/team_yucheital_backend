from __future__ import annotations

from io import BytesIO

import numpy as np
from fastapi.testclient import TestClient
from PIL import Image

from app.ai.interface import (
    PredictedDrain,
    PredictionOutput,
    ScenarioOutput,
)
from app.main import app, get_ai_model


client = TestClient(app)


class FakeTrainedAIModel:
    """Test-only model used to verify the production model contract."""

    version = "trained-test-model-1.0"
    name = "Test trained drainage model"

    def predict(self, terrain, *, drain_count, parameters):
        yy, xx = np.indices(terrain.image.shape)
        drainage_map = ((xx + yy) / max(float(xx.max() + yy.max()), 1.0)).astype(
            np.float32
        )
        drains = [
            PredictedDrain(
                x_normalized=(index + 1) / (drain_count + 1),
                y_normalized=(index + 1) / (drain_count + 1),
                confidence=0.9,
                drain_type="ai-predicted",
            )
            for index in range(drain_count)
        ]
        return PredictionOutput(
            drainage_map=drainage_map,
            drains=drains,
            metrics={"flood_area_ratio": 0.75, "total_runoff_index": 0.8},
            confidence=0.9,
        )

    def evaluate(self, terrain, *, drains, baseline, parameters):
        return ScenarioOutput(
            drainage_map=np.clip(baseline.drainage_map * 0.6, 0.0, 1.0),
            metrics={"flood_area_ratio": 0.4, "total_runoff_index": 0.5},
            confidence=0.85,
        )


def _sample_image_bytes() -> bytes:
    yy, xx = np.indices((64, 64))
    values = np.clip(255 - 2 * xx - yy, 0, 255).astype(np.uint8)
    output = BytesIO()
    Image.fromarray(values, mode="L").save(output, format="PNG")
    return output.getvalue()


def _upload(filename: str = "terrain.png") -> dict:
    response = client.post(
        "/api/upload-terrain",
        files={"file": (filename, _sample_image_bytes(), "image/png")},
        data={
            "input_type": "contour",
            "scale_m_per_pixel": "0.5",
            "coordinate_system": "LOCAL",
        },
    )
    assert response.status_code == 200, response.text
    return response.json()


def test_health_and_upload_work_without_model() -> None:
    app.dependency_overrides.clear()
    health = client.get("/health")
    assert health.status_code == 200
    assert health.json()["database_ready"] is True
    assert health.json()["ai_model_configured"] is False

    uploaded = _upload("upload-only.png")
    assert uploaded["status"] == "UPLOADED"
    assert uploaded["input_type"] == "contour"
    assert uploaded["preprocessing_version"].startswith("terrain-image-preprocess-")
    assert 0 <= uploaded["quality_score"] <= 1
    preview = client.get(uploaded["preview_url"])
    assert preview.status_code == 200
    assert preview.content.startswith(b"\x89PNG\r\n\x1a\n")


def test_prediction_never_fabricates_result_without_model() -> None:
    app.dependency_overrides.clear()
    uploaded = _upload("no-model.png")
    response = client.post(
        "/api/predict-drainage-map",
        json={"upload_id": uploaded["upload_id"], "drain_count": 2},
    )
    assert response.status_code == 503
    assert response.json()["detail"]["code"] == "MODEL_NOT_CONFIGURED"


def test_trained_ai_prediction_is_stored_and_retrievable() -> None:
    app.dependency_overrides[get_ai_model] = lambda: FakeTrainedAIModel()
    uploaded = _upload("prediction.png")
    request = {
        "upload_id": uploaded["upload_id"],
        "drain_count": 2,
        "rainfall_mm_per_hour": 50,
        "duration_minutes": 60,
    }
    response = client.post("/api/predict-drainage-map", json=request)
    assert response.status_code == 200, response.text
    body = response.json()
    assert body["result_type"] == "BASELINE"
    assert body["model_version"] == "trained-test-model-1.0"
    assert len(body["drains"]) == 2
    assert all(item["source"] == "AI_PREDICTED" for item in body["drains"])
    assert body["metrics"]["flood_area_ratio"] == 0.75

    image = client.get(body["drainage_map_url"])
    assert image.status_code == 200
    assert image.content.startswith(b"\x89PNG\r\n\x1a\n")

    stored = client.get(f"/api/result/{body['result_id']}")
    assert stored.status_code == 200
    assert stored.json()["result_id"] == body["result_id"]

    cached = client.post("/api/predict-drainage-map", json=request)
    assert cached.status_code == 200
    assert cached.json()["cache_hit"] is True
    assert cached.json()["result_id"] == body["result_id"]


def test_user_drain_scenario_uses_trained_model_evaluate() -> None:
    app.dependency_overrides[get_ai_model] = lambda: FakeTrainedAIModel()
    uploaded = _upload("scenario.png")
    baseline = client.post(
        "/api/predict-drainage-map",
        json={"upload_id": uploaded["upload_id"], "drain_count": 2},
    )
    assert baseline.status_code == 200, baseline.text
    baseline_body = baseline.json()

    scenario = client.post(
        "/api/evaluate-drain-settings",
        json={
            "upload_id": uploaded["upload_id"],
            "baseline_result_id": baseline_body["result_id"],
            "drains": [
                {
                    "id": "USER-D1",
                    "x": 0.35,
                    "y": 0.65,
                    "coordinate_mode": "normalized",
                    "drain_type": "grate",
                    "capacity_lps": 80,
                }
            ],
        },
    )
    assert scenario.status_code == 200, scenario.text
    body = scenario.json()
    assert body["result_type"] == "SCENARIO"
    assert body["parent_result_id"] == baseline_body["result_id"]
    assert body["drains"][0]["source"] == "USER_CONFIGURED"
    assert body["metrics"]["flood_area_ratio"] == 0.4
    assert body["delta_metrics"]["flood_area_ratio"] == -0.35

