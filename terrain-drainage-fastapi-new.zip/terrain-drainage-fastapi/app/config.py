from __future__ import annotations

import os
from pathlib import Path


APP_NAME = "Terrain Drainage AI API"
APP_VERSION = "1.0.0"

PROJECT_ROOT = Path(__file__).resolve().parent.parent
DATA_ROOT = Path(os.getenv("DATA_ROOT", PROJECT_ROOT / "data")).resolve()
STORAGE_ROOT = Path(os.getenv("STORAGE_ROOT", DATA_ROOT / "storage")).resolve()
DATABASE_URL = os.getenv(
    "DATABASE_URL",
    f"sqlite:///{(DATA_ROOT / 'terrain_drainage.db').as_posix()}",
)

# A production model must be provided as ``package.module:create_model``.
# The factory takes no arguments and returns an object implementing
# ``DrainageAIModel`` from app.ai.interface.
AI_MODEL_FACTORY = os.getenv("AI_MODEL_FACTORY", "").strip()
PREPROCESSING_VERSION = os.getenv(
    "PREPROCESSING_VERSION", "terrain-image-preprocess-1.0.0"
)

MAX_UPLOAD_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", 10 * 1024 * 1024))
MAX_IMAGE_PIXELS = int(os.getenv("MAX_IMAGE_PIXELS", 16_000_000))
ANALYSIS_MAX_DIMENSION = int(os.getenv("ANALYSIS_MAX_DIMENSION", 512))
MIN_IMAGE_SIDE = int(os.getenv("MIN_IMAGE_SIDE", 16))

ALLOWED_CONTENT_TYPES = {
    "image/png",
    "image/jpeg",
    "image/webp",
    "image/tiff",
}

