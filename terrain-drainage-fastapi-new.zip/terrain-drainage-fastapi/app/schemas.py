from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, model_validator


class HealthResponse(BaseModel):
    status: str
    service: str
    version: str
    database_ready: bool
    ai_model_configured: bool


class UploadResponse(BaseModel):
    request_id: str
    upload_id: str
    status: str
    filename: str
    input_type: str
    original_width: int
    original_height: int
    analysis_width: int
    analysis_height: int
    scale_m_per_pixel: float | None
    coordinate_system: str | None
    quality_score: float = Field(ge=0.0, le=1.0)
    quality_status: str
    quality_details: dict[str, float | int | str]
    preprocessing_version: str
    preview_url: str
    warnings: list[str]


class PredictionRequest(BaseModel):
    upload_id: str
    drain_count: int = Field(default=3, ge=1, le=10)
    rainfall_mm_per_hour: float | None = Field(default=None, gt=0)
    duration_minutes: float | None = Field(default=None, gt=0)
    runoff_coefficient: float | None = Field(default=None, gt=0, le=1)
    custom_parameters: dict[str, Any] = Field(default_factory=dict)


class DrainSetting(BaseModel):
    id: str = Field(min_length=1, max_length=80)
    x: float = Field(ge=0.0)
    y: float = Field(ge=0.0)
    coordinate_mode: Literal["normalized", "pixel"] = "normalized"
    drain_type: str | None = Field(default=None, max_length=80)
    capacity_lps: float | None = Field(default=None, gt=0)
    diameter_mm: float | None = Field(default=None, gt=0)
    discharge_coefficient: float | None = Field(default=None, gt=0, le=1)

    @model_validator(mode="after")
    def validate_normalized_coordinates(self) -> "DrainSetting":
        if self.coordinate_mode == "normalized" and (self.x > 1 or self.y > 1):
            raise ValueError("normalized 좌표의 x와 y는 0~1이어야 합니다.")
        return self


class ScenarioEvaluationRequest(BaseModel):
    upload_id: str
    drains: list[DrainSetting] = Field(min_length=1, max_length=50)
    baseline_result_id: str | None = None
    rainfall_mm_per_hour: float | None = Field(default=None, gt=0)
    duration_minutes: float | None = Field(default=None, gt=0)
    runoff_coefficient: float | None = Field(default=None, gt=0, le=1)
    custom_parameters: dict[str, Any] = Field(default_factory=dict)


class ResultDrainResponse(BaseModel):
    id: str
    order: int
    x_normalized: float = Field(ge=0.0, le=1.0)
    y_normalized: float = Field(ge=0.0, le=1.0)
    x_pixel: int
    y_pixel: int
    drain_type: str | None
    capacity_lps: float | None
    diameter_mm: float | None
    discharge_coefficient: float | None
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    source: str


class ResultResponse(BaseModel):
    request_id: str
    result_id: str
    upload_id: str
    parent_result_id: str | None
    result_type: Literal["BASELINE", "SCENARIO"]
    status: str
    model_version: str
    preprocessing_version: str
    cache_hit: bool
    metrics: dict[str, float]
    delta_metrics: dict[str, float] | None
    drains: list[ResultDrainResponse]
    drainage_map_url: str
    overlay_image_url: str
    processing_time_ms: int
    confidence: float | None = Field(default=None, ge=0.0, le=1.0)
    warnings: list[str]

