"""Strict contract and loader for the user-supplied trained AI model."""
