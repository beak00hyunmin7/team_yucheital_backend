from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol

import numpy as np


@dataclass(frozen=True)
class TerrainModelInput:
    """Preprocessed terrain input passed to the trained model only."""

    image: np.ndarray
    input_type: str
    scale_m_per_pixel: float | None
    coordinate_system: str | None
    original_width: int
    original_height: int


@dataclass(frozen=True)
class PredictedDrain:
    x_normalized: float
    y_normalized: float
    confidence: float | None = None
    drain_type: str | None = None
    capacity_lps: float | None = None


@dataclass(frozen=True)
class PredictionOutput:
    drainage_map: np.ndarray
    drains: list[PredictedDrain]
    metrics: dict[str, float] = field(default_factory=dict)
    confidence: float | None = None
    warnings: list[str] = field(default_factory=list)


@dataclass(frozen=True)
class ScenarioDrain:
    id: str
    x_normalized: float
    y_normalized: float
    drain_type: str | None = None
    capacity_lps: float | None = None
    diameter_mm: float | None = None
    discharge_coefficient: float | None = None


@dataclass(frozen=True)
class ScenarioOutput:
    drainage_map: np.ndarray
    metrics: dict[str, float] = field(default_factory=dict)
    confidence: float | None = None
    warnings: list[str] = field(default_factory=list)


class DrainageAIModel(Protocol):
    """Contract implemented by the trained prediction/scenario model.

    FastAPI never creates a drainage map or drain positions on behalf of this
    model. It only validates, stores, visualizes, and returns these outputs.
    """

    version: str
    name: str

    def predict(
        self,
        terrain: TerrainModelInput,
        *,
        drain_count: int,
        parameters: dict[str, Any],
    ) -> PredictionOutput: ...

    def evaluate(
        self,
        terrain: TerrainModelInput,
        *,
        drains: list[ScenarioDrain],
        baseline: PredictionOutput,
        parameters: dict[str, Any],
    ) -> ScenarioOutput: ...

