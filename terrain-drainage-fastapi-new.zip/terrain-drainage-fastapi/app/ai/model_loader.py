from __future__ import annotations

from functools import lru_cache
from importlib import import_module

from app.ai.interface import DrainageAIModel
from app.config import AI_MODEL_FACTORY


class ModelNotConfigured(RuntimeError):
    pass


class InvalidModelFactory(RuntimeError):
    pass


@lru_cache(maxsize=1)
def load_ai_model() -> DrainageAIModel:
    if not AI_MODEL_FACTORY:
        raise ModelNotConfigured(
            "학습된 AI 모델이 연결되지 않았습니다. "
            "AI_MODEL_FACTORY를 'package.module:create_model' 형식으로 설정해 주세요."
        )

    module_name, separator, factory_name = AI_MODEL_FACTORY.partition(":")
    if not separator or not module_name or not factory_name:
        raise InvalidModelFactory(
            "AI_MODEL_FACTORY는 'package.module:create_model' 형식이어야 합니다."
        )

    module = import_module(module_name)
    factory = getattr(module, factory_name, None)
    if not callable(factory):
        raise InvalidModelFactory(f"호출 가능한 모델 팩토리를 찾지 못했습니다: {AI_MODEL_FACTORY}")

    model = factory()
    for attribute in ("version", "name", "predict", "evaluate"):
        if not hasattr(model, attribute):
            raise InvalidModelFactory(f"학습 모델에 필수 항목이 없습니다: {attribute}")
    if not callable(model.predict) or not callable(model.evaluate):
        raise InvalidModelFactory("학습 모델의 predict/evaluate는 호출 가능해야 합니다.")
    return model


def model_is_configured() -> bool:
    return bool(AI_MODEL_FACTORY)

