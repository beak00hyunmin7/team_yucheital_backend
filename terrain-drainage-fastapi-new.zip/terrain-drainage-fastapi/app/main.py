from __future__ import annotations

import hashlib
import json
import math
import time
from numbers import Real
from typing import Annotated, Any
from uuid import uuid4

import numpy as np
from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.concurrency import run_in_threadpool
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import select, text
from sqlalchemy.orm import Session

from app.ai.interface import (
    DrainageAIModel,
    PredictedDrain,
    PredictionOutput,
    ScenarioDrain,
    ScenarioOutput,
    TerrainModelInput,
)
from app.ai.model_loader import (
    InvalidModelFactory,
    ModelNotConfigured,
    load_ai_model,
    model_is_configured,
)
from app.config import (
    ALLOWED_CONTENT_TYPES,
    ANALYSIS_MAX_DIMENSION,
    APP_NAME,
    APP_VERSION,
    MAX_IMAGE_PIXELS,
    MAX_UPLOAD_BYTES,
    MIN_IMAGE_SIDE,
    PREPROCESSING_VERSION,
    STORAGE_ROOT,
)
from app.database import SessionLocal, get_db, init_db
from app.models import (
    DrainageResult,
    ModelVersion,
    ProcessingRun,
    ResultArtifact,
    ResultDrain,
    TerrainUpload,
)
from app.schemas import (
    DrainSetting,
    HealthResponse,
    PredictionRequest,
    ResultDrainResponse,
    ResultResponse,
    ScenarioEvaluationRequest,
    UploadResponse,
)
from app.services.image_io import InvalidTerrainImage, PreparedTerrain, prepare_terrain
from app.services.storage import (
    StoredAsset,
    asset_url,
    ensure_storage,
    read_array,
    read_asset,
    save_result_array,
    save_result_png,
    save_upload_original,
    save_upload_preview,
)
from app.services.visualization import (
    render_drainage_map,
    render_overlay,
    validate_drainage_map,
)


INPUT_TYPES = {"contour", "terrain", "heightmap", "dem"}


def _initialize_runtime() -> None:
    ensure_storage()
    init_db()


_initialize_runtime()

app = FastAPI(
    title=APP_NAME,
    version=APP_VERSION,
    description=(
        "등고선·지형 이미지를 저장하고 학습된 AI 모델을 호출하여 배수맵과 "
        "배수구 위치를 반환합니다. FastAPI 자체는 배수구 위치를 생성하지 않습니다."
    ),
)
app.mount("/files", StaticFiles(directory=STORAGE_ROOT), name="analysis-files")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


def get_ai_model() -> DrainageAIModel:
    try:
        return load_ai_model()
    except ModelNotConfigured as exc:
        raise HTTPException(
            status_code=503,
            detail={"code": "MODEL_NOT_CONFIGURED", "message": str(exc)},
        ) from exc
    except (InvalidModelFactory, ImportError, AttributeError) as exc:
        raise HTTPException(
            status_code=503,
            detail={"code": "MODEL_LOAD_FAILED", "message": str(exc)},
        ) from exc


@app.get("/health", response_model=HealthResponse, tags=["system"])
async def health(db: Session = Depends(get_db)) -> HealthResponse:
    db.execute(text("SELECT 1"))
    return HealthResponse(
        status="ok",
        service=APP_NAME,
        version=APP_VERSION,
        database_ready=True,
        ai_model_configured=model_is_configured(),
    )


@app.post(
    "/api/upload-terrain",
    response_model=UploadResponse,
    tags=["terrain"],
    summary="지형 이미지를 업로드하고 전처리·품질검사를 수행합니다",
)
async def upload_terrain(
    file: Annotated[UploadFile, File(description="등고선·지형·heightmap·DEM 이미지")],
    input_type: Annotated[str, Form()] = "contour",
    scale_m_per_pixel: Annotated[float | None, Form(gt=0)] = None,
    coordinate_system: Annotated[str | None, Form(max_length=100)] = None,
    db: Session = Depends(get_db),
) -> UploadResponse:
    started_at = time.perf_counter()
    request_id = str(uuid4())
    normalized_type = input_type.strip().lower()
    if normalized_type not in INPUT_TYPES:
        raise HTTPException(
            status_code=422,
            detail=f"input_type은 {', '.join(sorted(INPUT_TYPES))} 중 하나여야 합니다.",
        )

    data = await _read_upload(file)
    try:
        prepared = await run_in_threadpool(
            prepare_terrain,
            data,
            input_type=normalized_type,
            max_pixels=MAX_IMAGE_PIXELS,
            analysis_max_dimension=ANALYSIS_MAX_DIMENSION,
            min_image_side=MIN_IMAGE_SIDE,
        )
    except InvalidTerrainImage as exc:
        _record_run(
            db,
            request_id=request_id,
            stage="UPLOAD_PREPROCESS",
            status="FAILED",
            latency_ms=_elapsed_ms(started_at),
            error_code="INVALID_TERRAIN_IMAGE",
            error_message=str(exc),
        )
        db.commit()
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    upload_id = str(uuid4())
    original_asset = save_upload_original(
        upload_id=upload_id,
        data=data,
        content_type=file.content_type,
        width=prepared.original_width,
        height=prepared.original_height,
    )
    preview_asset = save_upload_preview(
        upload_id=upload_id, data=prepared.preview_png
    )
    upload = TerrainUpload(
        id=upload_id,
        request_id=request_id,
        image_hash=hashlib.sha256(data).hexdigest(),
        original_filename=file.filename or "upload",
        mime_type=file.content_type or "image/png",
        input_type=normalized_type,
        original_width=prepared.original_width,
        original_height=prepared.original_height,
        analysis_width=prepared.analysis_width,
        analysis_height=prepared.analysis_height,
        scale_m_per_pixel=scale_m_per_pixel,
        coordinate_system=coordinate_system,
        quality_score=prepared.quality_score,
        quality_status=prepared.quality_status,
        quality_details_json=json.dumps(prepared.quality_details, ensure_ascii=False),
        preprocessing_version=PREPROCESSING_VERSION,
        original_path=original_asset.relative_path,
        preview_path=preview_asset.relative_path,
    )
    db.add(upload)
    db.flush()
    _record_run(
        db,
        request_id=request_id,
        upload_id=upload_id,
        stage="UPLOAD_PREPROCESS",
        status="COMPLETED",
        latency_ms=_elapsed_ms(started_at),
    )
    db.commit()
    return _upload_response(upload, warnings=prepared.warnings)


@app.post(
    "/api/predict-drainage-map",
    response_model=ResultResponse,
    tags=["prediction"],
    summary="학습된 AI로 기본 배수맵과 배수구 위치를 예측합니다",
)
async def predict_drainage_map(
    payload: PredictionRequest,
    model: DrainageAIModel = Depends(get_ai_model),
    db: Session = Depends(get_db),
) -> ResultResponse:
    started_at = time.perf_counter()
    request_id = str(uuid4())
    upload = _get_upload(db, payload.upload_id)
    parameters = payload.model_dump(exclude={"upload_id"}, mode="json")
    cache_key = _cache_key(
        "BASELINE", upload.image_hash, model.version, PREPROCESSING_VERSION, parameters
    )
    cached = db.scalar(
        select(DrainageResult)
        .where(
            DrainageResult.cache_key == cache_key,
            DrainageResult.status == "COMPLETED",
        )
        .order_by(DrainageResult.created_at.desc())
    )
    if cached is not None:
        latency = _elapsed_ms(started_at)
        _record_run(
            db,
            request_id=request_id,
            upload_id=upload.id,
            result_id=cached.id,
            stage="AI_PREDICTION",
            status="COMPLETED",
            model_version=model.version,
            latency_ms=latency,
            cache_hit=True,
        )
        db.commit()
        return _result_response(
            cached,
            request_id=request_id,
            cache_hit=True,
            processing_time_ms=latency,
        )

    terrain, prepared = await run_in_threadpool(_terrain_input, upload)
    try:
        output = await run_in_threadpool(
            model.predict,
            terrain,
            drain_count=payload.drain_count,
            parameters=parameters,
        )
        drainage_map, predicted_drains, metrics, confidence, warnings = (
            _validate_prediction_output(output, requested_count=payload.drain_count)
        )
    except Exception as exc:
        _record_run(
            db,
            request_id=request_id,
            upload_id=upload.id,
            stage="AI_PREDICTION",
            status="FAILED",
            model_version=getattr(model, "version", None),
            latency_ms=_elapsed_ms(started_at),
            error_code="AI_INFERENCE_FAILED",
            error_message=str(exc),
        )
        db.commit()
        raise HTTPException(
            status_code=502,
            detail={"code": "AI_INFERENCE_FAILED", "message": str(exc)},
        ) from exc

    result_id = str(uuid4())
    response_drains = [
        _prediction_drain_payload(item, index, upload)
        for index, item in enumerate(predicted_drains, start=1)
    ]
    result = _persist_result(
        db,
        result_id=result_id,
        request_id=request_id,
        upload=upload,
        parent_result_id=None,
        cache_key=cache_key,
        result_type="BASELINE",
        model=model,
        parameters=parameters,
        metrics=metrics,
        delta_metrics=None,
        confidence=confidence,
        warnings=warnings,
        drainage_map=drainage_map,
        drains=response_drains,
        processing_time_ms=_elapsed_ms(started_at),
        output_size=(prepared.original_width, prepared.original_height),
    )
    _record_run(
        db,
        request_id=request_id,
        upload_id=upload.id,
        result_id=result.id,
        stage="AI_PREDICTION",
        status="COMPLETED",
        model_version=model.version,
        latency_ms=result.processing_time_ms,
    )
    db.commit()
    return _result_response(result, request_id=request_id, cache_hit=False)


@app.post(
    "/api/evaluate-drain-settings",
    response_model=ResultResponse,
    tags=["scenario"],
    summary="학습된 시나리오 모델로 사용자 배수구 설정의 영향을 계산합니다",
)
async def evaluate_drain_settings(
    payload: ScenarioEvaluationRequest,
    model: DrainageAIModel = Depends(get_ai_model),
    db: Session = Depends(get_db),
) -> ResultResponse:
    started_at = time.perf_counter()
    request_id = str(uuid4())
    upload = _get_upload(db, payload.upload_id)
    baseline = _get_baseline(db, upload.id, payload.baseline_result_id)
    normalized_drains = [_normalize_drain(item, upload) for item in payload.drains]
    parameters = payload.model_dump(
        exclude={"upload_id", "baseline_result_id", "drains"}, mode="json"
    )
    cache_payload = {
        "baseline_result_id": baseline.id,
        "drains": [item.__dict__ for item in normalized_drains],
        "parameters": parameters,
    }
    cache_key = _cache_key(
        "SCENARIO",
        upload.image_hash,
        model.version,
        PREPROCESSING_VERSION,
        cache_payload,
    )
    cached = db.scalar(
        select(DrainageResult)
        .where(
            DrainageResult.cache_key == cache_key,
            DrainageResult.status == "COMPLETED",
        )
        .order_by(DrainageResult.created_at.desc())
    )
    if cached is not None:
        latency = _elapsed_ms(started_at)
        _record_run(
            db,
            request_id=request_id,
            upload_id=upload.id,
            result_id=cached.id,
            stage="SCENARIO_EVALUATION",
            status="COMPLETED",
            model_version=model.version,
            latency_ms=latency,
            cache_hit=True,
        )
        db.commit()
        return _result_response(
            cached,
            request_id=request_id,
            cache_hit=True,
            processing_time_ms=latency,
        )

    terrain, prepared = await run_in_threadpool(_terrain_input, upload)
    baseline_output = _baseline_output(baseline)
    try:
        output = await run_in_threadpool(
            model.evaluate,
            terrain,
            drains=normalized_drains,
            baseline=baseline_output,
            parameters=parameters,
        )
        drainage_map, metrics, confidence, warnings = _validate_scenario_output(output)
    except NotImplementedError as exc:
        _record_run(
            db,
            request_id=request_id,
            upload_id=upload.id,
            stage="SCENARIO_EVALUATION",
            status="FAILED",
            model_version=model.version,
            latency_ms=_elapsed_ms(started_at),
            error_code="SCENARIO_MODEL_NOT_CONFIGURED",
            error_message=str(exc),
        )
        db.commit()
        raise HTTPException(
            status_code=503,
            detail={"code": "SCENARIO_MODEL_NOT_CONFIGURED", "message": str(exc)},
        ) from exc
    except Exception as exc:
        _record_run(
            db,
            request_id=request_id,
            upload_id=upload.id,
            stage="SCENARIO_EVALUATION",
            status="FAILED",
            model_version=getattr(model, "version", None),
            latency_ms=_elapsed_ms(started_at),
            error_code="SCENARIO_INFERENCE_FAILED",
            error_message=str(exc),
        )
        db.commit()
        raise HTTPException(
            status_code=502,
            detail={"code": "SCENARIO_INFERENCE_FAILED", "message": str(exc)},
        ) from exc

    baseline_metrics = _metrics(baseline.metrics_json)
    delta_metrics = {
        key: round(value - baseline_metrics[key], 6)
        for key, value in metrics.items()
        if key in baseline_metrics
    }
    response_drains = [
        _scenario_drain_payload(item, index, upload)
        for index, item in enumerate(normalized_drains, start=1)
    ]
    result = _persist_result(
        db,
        result_id=str(uuid4()),
        request_id=request_id,
        upload=upload,
        parent_result_id=baseline.id,
        cache_key=cache_key,
        result_type="SCENARIO",
        model=model,
        parameters=parameters,
        metrics=metrics,
        delta_metrics=delta_metrics,
        confidence=confidence,
        warnings=warnings,
        drainage_map=drainage_map,
        drains=response_drains,
        processing_time_ms=_elapsed_ms(started_at),
        output_size=(prepared.original_width, prepared.original_height),
    )
    _record_run(
        db,
        request_id=request_id,
        upload_id=upload.id,
        result_id=result.id,
        stage="SCENARIO_EVALUATION",
        status="COMPLETED",
        model_version=model.version,
        latency_ms=result.processing_time_ms,
    )
    db.commit()
    return _result_response(result, request_id=request_id, cache_hit=False)


@app.get(
    "/api/result/{result_id}",
    response_model=ResultResponse,
    tags=["result"],
    summary="저장된 기본 또는 사용자 시나리오 결과를 조회합니다",
)
async def get_result(
    result_id: str, db: Session = Depends(get_db)
) -> ResultResponse:
    result = db.get(DrainageResult, result_id)
    if result is None or result.status != "COMPLETED":
        raise HTTPException(status_code=404, detail="완료된 결과를 찾을 수 없습니다.")
    return _result_response(result, request_id=result.request_id, cache_hit=False)


@app.get("/", include_in_schema=False)
async def root() -> dict[str, str]:
    return {
        "message": APP_NAME,
        "swagger_ui": "/docs",
        "health": "/health",
    }


async def _read_upload(file: UploadFile) -> bytes:
    if file.content_type and file.content_type not in ALLOWED_CONTENT_TYPES:
        raise HTTPException(
            status_code=415,
            detail="PNG, JPEG, WEBP 또는 TIFF 이미지만 업로드할 수 있습니다.",
        )
    data = await file.read(MAX_UPLOAD_BYTES + 1)
    await file.close()
    if not data:
        raise HTTPException(status_code=400, detail="업로드한 이미지가 비어 있습니다.")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"파일 크기는 {MAX_UPLOAD_BYTES // (1024 * 1024)}MB 이하여야 합니다.",
        )
    return data


def _get_upload(db: Session, upload_id: str) -> TerrainUpload:
    upload = db.get(TerrainUpload, upload_id)
    if upload is None:
        raise HTTPException(status_code=404, detail="업로드 정보를 찾을 수 없습니다.")
    return upload


def _get_baseline(
    db: Session, upload_id: str, baseline_result_id: str | None
) -> DrainageResult:
    if baseline_result_id:
        result = db.get(DrainageResult, baseline_result_id)
        if (
            result is None
            or result.upload_id != upload_id
            or result.result_type != "BASELINE"
            or result.status != "COMPLETED"
        ):
            raise HTTPException(status_code=404, detail="기본 예측 결과를 찾을 수 없습니다.")
        return result
    result = db.scalar(
        select(DrainageResult)
        .where(
            DrainageResult.upload_id == upload_id,
            DrainageResult.result_type == "BASELINE",
            DrainageResult.status == "COMPLETED",
        )
        .order_by(DrainageResult.created_at.desc())
    )
    if result is None:
        raise HTTPException(
            status_code=409,
            detail="먼저 /api/predict-drainage-map으로 기본 예측을 생성해 주세요.",
        )
    return result


def _terrain_input(upload: TerrainUpload) -> tuple[TerrainModelInput, PreparedTerrain]:
    prepared = prepare_terrain(
        read_asset(upload.original_path),
        input_type=upload.input_type,
        max_pixels=MAX_IMAGE_PIXELS,
        analysis_max_dimension=ANALYSIS_MAX_DIMENSION,
        min_image_side=MIN_IMAGE_SIDE,
    )
    return (
        TerrainModelInput(
            image=prepared.model_image,
            input_type=upload.input_type,
            scale_m_per_pixel=upload.scale_m_per_pixel,
            coordinate_system=upload.coordinate_system,
            original_width=upload.original_width,
            original_height=upload.original_height,
        ),
        prepared,
    )


def _validate_prediction_output(
    output: PredictionOutput, *, requested_count: int
) -> tuple[np.ndarray, list[PredictedDrain], dict[str, float], float | None, list[str]]:
    if not isinstance(output, PredictionOutput):
        raise ValueError("AI predict는 PredictionOutput을 반환해야 합니다.")
    drainage_map = validate_drainage_map(output.drainage_map)
    if len(output.drains) != requested_count:
        raise ValueError(
            f"AI가 반환한 배수구는 {len(output.drains)}개이며 요청값 {requested_count}개와 다릅니다."
        )
    for item in output.drains:
        _validate_normalized(item.x_normalized, item.y_normalized)
        _validate_confidence(item.confidence)
    return (
        drainage_map,
        output.drains,
        _validate_metrics(output.metrics),
        _validate_confidence(output.confidence),
        list(output.warnings),
    )


def _validate_scenario_output(
    output: ScenarioOutput,
) -> tuple[np.ndarray, dict[str, float], float | None, list[str]]:
    if not isinstance(output, ScenarioOutput):
        raise ValueError("AI evaluate는 ScenarioOutput을 반환해야 합니다.")
    return (
        validate_drainage_map(output.drainage_map),
        _validate_metrics(output.metrics),
        _validate_confidence(output.confidence),
        list(output.warnings),
    )


def _validate_metrics(values: dict[str, float]) -> dict[str, float]:
    metrics: dict[str, float] = {}
    for key, value in values.items():
        if not isinstance(key, str) or not isinstance(value, Real):
            raise ValueError("AI metrics는 문자열 키와 숫자 값으로 구성되어야 합니다.")
        number = float(value)
        if not math.isfinite(number):
            raise ValueError(f"AI metric이 유효한 숫자가 아닙니다: {key}")
        metrics[key] = round(number, 6)
    return metrics


def _validate_normalized(x: float, y: float) -> None:
    if not math.isfinite(x) or not math.isfinite(y) or not (0 <= x <= 1 and 0 <= y <= 1):
        raise ValueError("AI 배수구 좌표는 0~1 범위의 normalized 좌표여야 합니다.")


def _validate_confidence(value: float | None) -> float | None:
    if value is None:
        return None
    number = float(value)
    if not math.isfinite(number) or not 0 <= number <= 1:
        raise ValueError("AI confidence는 0~1 범위여야 합니다.")
    return round(number, 6)


def _normalize_drain(item: DrainSetting, upload: TerrainUpload) -> ScenarioDrain:
    if item.coordinate_mode == "normalized":
        x_normalized, y_normalized = float(item.x), float(item.y)
    else:
        if item.x > upload.original_width - 1 or item.y > upload.original_height - 1:
            raise HTTPException(status_code=422, detail=f"배수구 {item.id}가 이미지 범위를 벗어났습니다.")
        x_normalized = float(item.x) / max(upload.original_width - 1, 1)
        y_normalized = float(item.y) / max(upload.original_height - 1, 1)
    _validate_normalized(x_normalized, y_normalized)
    return ScenarioDrain(
        id=item.id,
        x_normalized=x_normalized,
        y_normalized=y_normalized,
        drain_type=item.drain_type,
        capacity_lps=item.capacity_lps,
        diameter_mm=item.diameter_mm,
        discharge_coefficient=item.discharge_coefficient,
    )


def _prediction_drain_payload(
    item: PredictedDrain, order: int, upload: TerrainUpload
) -> dict[str, Any]:
    return {
        "id": f"AI-{order}",
        "order": order,
        "x_normalized": float(item.x_normalized),
        "y_normalized": float(item.y_normalized),
        "x_pixel": round(item.x_normalized * max(upload.original_width - 1, 1)),
        "y_pixel": round(item.y_normalized * max(upload.original_height - 1, 1)),
        "drain_type": item.drain_type,
        "capacity_lps": item.capacity_lps,
        "diameter_mm": None,
        "discharge_coefficient": None,
        "confidence": item.confidence,
        "source": "AI_PREDICTED",
    }


def _scenario_drain_payload(
    item: ScenarioDrain, order: int, upload: TerrainUpload
) -> dict[str, Any]:
    return {
        "id": item.id,
        "order": order,
        "x_normalized": item.x_normalized,
        "y_normalized": item.y_normalized,
        "x_pixel": round(item.x_normalized * max(upload.original_width - 1, 1)),
        "y_pixel": round(item.y_normalized * max(upload.original_height - 1, 1)),
        "drain_type": item.drain_type,
        "capacity_lps": item.capacity_lps,
        "diameter_mm": item.diameter_mm,
        "discharge_coefficient": item.discharge_coefficient,
        "confidence": None,
        "source": "USER_CONFIGURED",
    }


def _persist_result(
    db: Session,
    *,
    result_id: str,
    request_id: str,
    upload: TerrainUpload,
    parent_result_id: str | None,
    cache_key: str,
    result_type: str,
    model: DrainageAIModel,
    parameters: dict[str, Any],
    metrics: dict[str, float],
    delta_metrics: dict[str, float] | None,
    confidence: float | None,
    warnings: list[str],
    drainage_map: np.ndarray,
    drains: list[dict[str, Any]],
    processing_time_ms: int,
    output_size: tuple[int, int],
) -> DrainageResult:
    _ensure_model_version(db, model)
    map_png = render_drainage_map(drainage_map, output_size=output_size)
    overlay_png = render_overlay(
        drainage_map,
        drains=[(f"D{item['order']}", item["x_normalized"], item["y_normalized"]) for item in drains],
        output_size=output_size,
    )
    assets = (
        save_result_png(
            result_id=result_id,
            filename="drainage_map.png",
            kind="DRAINAGE_MAP_PNG",
            data=map_png,
        ),
        save_result_png(
            result_id=result_id,
            filename="drain_overlay.png",
            kind="DRAIN_OVERLAY_PNG",
            data=overlay_png,
        ),
        save_result_array(result_id=result_id, array=drainage_map),
    )
    result = DrainageResult(
        id=result_id,
        request_id=request_id,
        upload_id=upload.id,
        parent_result_id=parent_result_id,
        cache_key=cache_key,
        result_type=result_type,
        status="COMPLETED",
        model_version=model.version,
        preprocessing_version=PREPROCESSING_VERSION,
        parameters_json=json.dumps(parameters, sort_keys=True, ensure_ascii=False),
        metrics_json=json.dumps(metrics, sort_keys=True, ensure_ascii=False),
        delta_metrics_json=(
            json.dumps(delta_metrics, sort_keys=True, ensure_ascii=False)
            if delta_metrics is not None
            else None
        ),
        warnings_json=json.dumps(warnings, ensure_ascii=False),
        confidence=confidence,
        processing_time_ms=processing_time_ms,
    )
    db.add(result)
    db.flush()
    for item in drains:
        db.add(
            ResultDrain(
                result_id=result_id,
                drain_order=item["order"],
                client_drain_id=item["id"],
                x_normalized=item["x_normalized"],
                y_normalized=item["y_normalized"],
                x_pixel=item["x_pixel"],
                y_pixel=item["y_pixel"],
                drain_type=item["drain_type"],
                capacity_lps=item["capacity_lps"],
                diameter_mm=item["diameter_mm"],
                discharge_coefficient=item["discharge_coefficient"],
                confidence=item["confidence"],
                source=item["source"],
                payload_json=json.dumps(item, ensure_ascii=False),
            )
        )
    for asset in assets:
        db.add(_artifact_record(result_id, asset))
    db.flush()
    return result


def _baseline_output(result: DrainageResult) -> PredictionOutput:
    array_artifact = _artifact(result, "DRAINAGE_MAP_ARRAY")
    return PredictionOutput(
        drainage_map=read_array(array_artifact.storage_path),
        drains=[
            PredictedDrain(
                x_normalized=item.x_normalized,
                y_normalized=item.y_normalized,
                confidence=item.confidence,
                drain_type=item.drain_type,
                capacity_lps=item.capacity_lps,
            )
            for item in sorted(result.drains, key=lambda drain: drain.drain_order)
        ],
        metrics=_metrics(result.metrics_json),
        confidence=result.confidence,
        warnings=json.loads(result.warnings_json),
    )


def _ensure_model_version(db: Session, model: DrainageAIModel) -> None:
    if db.get(ModelVersion, model.version) is None:
        db.add(
            ModelVersion(
                version=model.version,
                name=model.name,
                is_active=True,
            )
        )
        db.flush()


def _artifact_record(result_id: str, asset: StoredAsset) -> ResultArtifact:
    return ResultArtifact(
        result_id=result_id,
        kind=asset.kind,
        storage_path=asset.relative_path,
        mime_type=asset.mime_type,
        file_hash=asset.file_hash,
        width=asset.width,
        height=asset.height,
    )


def _artifact(result: DrainageResult, kind: str) -> ResultArtifact:
    for item in result.artifacts:
        if item.kind == kind:
            return item
    raise HTTPException(status_code=500, detail=f"저장된 {kind} 결과가 없습니다.")


def _result_response(
    result: DrainageResult,
    *,
    request_id: str,
    cache_hit: bool,
    processing_time_ms: int | None = None,
) -> ResultResponse:
    map_artifact = _artifact(result, "DRAINAGE_MAP_PNG")
    overlay_artifact = _artifact(result, "DRAIN_OVERLAY_PNG")
    drains = [
        ResultDrainResponse(
            id=item.client_drain_id,
            order=item.drain_order,
            x_normalized=item.x_normalized,
            y_normalized=item.y_normalized,
            x_pixel=item.x_pixel,
            y_pixel=item.y_pixel,
            drain_type=item.drain_type,
            capacity_lps=item.capacity_lps,
            diameter_mm=item.diameter_mm,
            discharge_coefficient=item.discharge_coefficient,
            confidence=item.confidence,
            source=item.source,
        )
        for item in sorted(result.drains, key=lambda drain: drain.drain_order)
    ]
    return ResultResponse(
        request_id=request_id,
        result_id=result.id,
        upload_id=result.upload_id,
        parent_result_id=result.parent_result_id,
        result_type=result.result_type,
        status=result.status,
        model_version=result.model_version,
        preprocessing_version=result.preprocessing_version,
        cache_hit=cache_hit,
        metrics=_metrics(result.metrics_json),
        delta_metrics=(
            _metrics(result.delta_metrics_json) if result.delta_metrics_json else None
        ),
        drains=drains,
        drainage_map_url=asset_url(map_artifact.storage_path),
        overlay_image_url=asset_url(overlay_artifact.storage_path),
        processing_time_ms=processing_time_ms or result.processing_time_ms,
        confidence=result.confidence,
        warnings=json.loads(result.warnings_json),
    )


def _upload_response(upload: TerrainUpload, *, warnings: list[str]) -> UploadResponse:
    return UploadResponse(
        request_id=upload.request_id,
        upload_id=upload.id,
        status="UPLOADED",
        filename=upload.original_filename,
        input_type=upload.input_type,
        original_width=upload.original_width,
        original_height=upload.original_height,
        analysis_width=upload.analysis_width,
        analysis_height=upload.analysis_height,
        scale_m_per_pixel=upload.scale_m_per_pixel,
        coordinate_system=upload.coordinate_system,
        quality_score=upload.quality_score,
        quality_status=upload.quality_status,
        quality_details=json.loads(upload.quality_details_json),
        preprocessing_version=upload.preprocessing_version,
        preview_url=asset_url(upload.preview_path),
        warnings=warnings,
    )


def _metrics(payload: str) -> dict[str, float]:
    return {key: float(value) for key, value in json.loads(payload).items()}


def _cache_key(*parts: Any) -> str:
    serialized = json.dumps(parts, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
    return hashlib.sha256(serialized.encode("utf-8")).hexdigest()


def _record_run(
    db: Session,
    *,
    request_id: str,
    stage: str,
    status: str,
    latency_ms: int,
    upload_id: str | None = None,
    result_id: str | None = None,
    model_version: str | None = None,
    cache_hit: bool = False,
    error_code: str | None = None,
    error_message: str | None = None,
) -> None:
    db.add(
        ProcessingRun(
            request_id=request_id,
            upload_id=upload_id,
            result_id=result_id,
            stage=stage,
            status=status,
            model_version=model_version,
            preprocessing_version=PREPROCESSING_VERSION,
            latency_ms=latency_ms,
            cache_hit=cache_hit,
            error_code=error_code,
            error_message=error_message,
        )
    )


def _elapsed_ms(started_at: float) -> int:
    return max(1, round((time.perf_counter() - started_at) * 1000))
