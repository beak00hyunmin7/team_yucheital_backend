from __future__ import annotations

from datetime import datetime, timezone

from sqlalchemy import Boolean, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import Mapped, mapped_column, relationship

from app.database import Base


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


class ModelVersion(Base):
    __tablename__ = "model_versions"

    version: Mapped[str] = mapped_column(String(80), primary_key=True)
    name: Mapped[str] = mapped_column(String(200))
    model_path: Mapped[str | None] = mapped_column(String(500), nullable=True)
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)


class TerrainUpload(Base):
    __tablename__ = "terrain_uploads"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    request_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    image_hash: Mapped[str] = mapped_column(String(64), index=True)
    original_filename: Mapped[str] = mapped_column(String(255))
    mime_type: Mapped[str] = mapped_column(String(100))
    input_type: Mapped[str] = mapped_column(String(30))
    original_width: Mapped[int] = mapped_column(Integer)
    original_height: Mapped[int] = mapped_column(Integer)
    analysis_width: Mapped[int] = mapped_column(Integer)
    analysis_height: Mapped[int] = mapped_column(Integer)
    scale_m_per_pixel: Mapped[float | None] = mapped_column(Float, nullable=True)
    coordinate_system: Mapped[str | None] = mapped_column(String(100), nullable=True)
    quality_score: Mapped[float] = mapped_column(Float)
    quality_status: Mapped[str] = mapped_column(String(30), index=True)
    quality_details_json: Mapped[str] = mapped_column(Text)
    preprocessing_version: Mapped[str] = mapped_column(String(80))
    original_path: Mapped[str] = mapped_column(String(500))
    preview_path: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    results: Mapped[list["DrainageResult"]] = relationship(
        back_populates="upload", cascade="all, delete-orphan"
    )


class DrainageResult(Base):
    __tablename__ = "drainage_results"

    id: Mapped[str] = mapped_column(String(36), primary_key=True)
    request_id: Mapped[str] = mapped_column(String(36), unique=True, index=True)
    upload_id: Mapped[str] = mapped_column(ForeignKey("terrain_uploads.id"), index=True)
    parent_result_id: Mapped[str | None] = mapped_column(
        ForeignKey("drainage_results.id"), nullable=True, index=True
    )
    cache_key: Mapped[str] = mapped_column(String(64), index=True)
    result_type: Mapped[str] = mapped_column(String(30), index=True)
    status: Mapped[str] = mapped_column(String(30), index=True)
    model_version: Mapped[str] = mapped_column(ForeignKey("model_versions.version"))
    preprocessing_version: Mapped[str] = mapped_column(String(80))
    parameters_json: Mapped[str] = mapped_column(Text)
    metrics_json: Mapped[str] = mapped_column(Text)
    delta_metrics_json: Mapped[str | None] = mapped_column(Text, nullable=True)
    warnings_json: Mapped[str] = mapped_column(Text)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    processing_time_ms: Mapped[int] = mapped_column(Integer)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    upload: Mapped[TerrainUpload] = relationship(back_populates="results")
    drains: Mapped[list["ResultDrain"]] = relationship(
        back_populates="result", cascade="all, delete-orphan"
    )
    artifacts: Mapped[list["ResultArtifact"]] = relationship(
        back_populates="result", cascade="all, delete-orphan"
    )


class ResultDrain(Base):
    __tablename__ = "result_drains"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    result_id: Mapped[str] = mapped_column(ForeignKey("drainage_results.id"), index=True)
    drain_order: Mapped[int] = mapped_column(Integer)
    client_drain_id: Mapped[str] = mapped_column(String(80))
    x_normalized: Mapped[float] = mapped_column(Float)
    y_normalized: Mapped[float] = mapped_column(Float)
    x_pixel: Mapped[int] = mapped_column(Integer)
    y_pixel: Mapped[int] = mapped_column(Integer)
    drain_type: Mapped[str | None] = mapped_column(String(80), nullable=True)
    capacity_lps: Mapped[float | None] = mapped_column(Float, nullable=True)
    diameter_mm: Mapped[float | None] = mapped_column(Float, nullable=True)
    discharge_coefficient: Mapped[float | None] = mapped_column(Float, nullable=True)
    confidence: Mapped[float | None] = mapped_column(Float, nullable=True)
    source: Mapped[str] = mapped_column(String(30))
    payload_json: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    result: Mapped[DrainageResult] = relationship(back_populates="drains")


class ResultArtifact(Base):
    __tablename__ = "result_artifacts"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    result_id: Mapped[str] = mapped_column(ForeignKey("drainage_results.id"), index=True)
    kind: Mapped[str] = mapped_column(String(40))
    storage_path: Mapped[str] = mapped_column(String(500))
    mime_type: Mapped[str] = mapped_column(String(100))
    file_hash: Mapped[str] = mapped_column(String(64))
    width: Mapped[int] = mapped_column(Integer)
    height: Mapped[int] = mapped_column(Integer)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)

    result: Mapped[DrainageResult] = relationship(back_populates="artifacts")


class ProcessingRun(Base):
    __tablename__ = "processing_runs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    request_id: Mapped[str] = mapped_column(String(36), index=True)
    upload_id: Mapped[str | None] = mapped_column(
        ForeignKey("terrain_uploads.id"), nullable=True, index=True
    )
    result_id: Mapped[str | None] = mapped_column(
        ForeignKey("drainage_results.id"), nullable=True, index=True
    )
    stage: Mapped[str] = mapped_column(String(40), index=True)
    status: Mapped[str] = mapped_column(String(30), index=True)
    model_version: Mapped[str | None] = mapped_column(String(80), nullable=True)
    preprocessing_version: Mapped[str] = mapped_column(String(80))
    latency_ms: Mapped[int] = mapped_column(Integer)
    cache_hit: Mapped[bool] = mapped_column(Boolean, default=False)
    error_code: Mapped[str | None] = mapped_column(String(80), nullable=True)
    error_message: Mapped[str | None] = mapped_column(Text, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), default=utc_now)
