from __future__ import annotations

from dataclasses import dataclass
from io import BytesIO

import numpy as np
from PIL import Image, ImageOps, UnidentifiedImageError


@dataclass(frozen=True)
class PreparedTerrain:
    model_image: np.ndarray
    preview_png: bytes
    original_width: int
    original_height: int
    analysis_width: int
    analysis_height: int
    quality_score: float
    quality_status: str
    quality_details: dict[str, float | int | str]
    warnings: list[str]


class InvalidTerrainImage(ValueError):
    pass


def prepare_terrain(
    data: bytes,
    *,
    input_type: str,
    max_pixels: int,
    analysis_max_dimension: int,
    min_image_side: int,
) -> PreparedTerrain:
    try:
        with Image.open(BytesIO(data)) as probe:
            width, height = probe.size
            if width < min_image_side or height < min_image_side:
                raise InvalidTerrainImage(
                    f"이미지의 가로와 세로는 각각 {min_image_side}픽셀 이상이어야 합니다."
                )
            if width * height > max_pixels:
                raise InvalidTerrainImage(
                    f"이미지가 너무 큽니다. 최대 허용 픽셀 수는 {max_pixels:,}입니다."
                )
            probe.verify()
        with Image.open(BytesIO(data)) as source:
            source = ImageOps.exif_transpose(source)
            original_rgb = _to_rgb_on_white(source)
    except (UnidentifiedImageError, OSError) as exc:
        raise InvalidTerrainImage("PNG, JPEG, WEBP 또는 TIFF 이미지가 아닙니다.") from exc

    analysis_size = _fit_size(width, height, analysis_max_dimension)
    grayscale = original_rgb.convert("L").resize(
        analysis_size, Image.Resampling.BILINEAR
    )
    model_image = np.asarray(grayscale, dtype=np.float32) / 255.0

    dynamic_range = float(np.ptp(model_image))
    contrast_std = float(np.std(model_image))
    edge_density = _edge_density(model_image)
    resolution_score = min(1.0, min(width, height) / 512.0)
    contrast_score = min(1.0, dynamic_range / 0.35)
    edge_score = min(1.0, edge_density / 0.08)
    if input_type in {"contour", "terrain"}:
        quality_score = 0.35 * resolution_score + 0.30 * contrast_score + 0.35 * edge_score
    else:
        quality_score = 0.35 * resolution_score + 0.45 * contrast_score + 0.20 * edge_score
    quality_score = round(float(np.clip(quality_score, 0.0, 1.0)), 6)

    if dynamic_range < 0.01:
        raise InvalidTerrainImage(
            "영상의 명암 변화가 거의 없어 학습 모델 입력으로 사용할 수 없습니다."
        )

    warnings: list[str] = []
    quality_status = "PASS"
    if quality_score < 0.45:
        quality_status = "WARNING"
        warnings.append(
            "입력 품질이 낮습니다. 더 높은 해상도와 선명한 등고선 또는 지형 이미지를 권장합니다."
        )
    if input_type == "contour" and edge_density < 0.005:
        quality_status = "WARNING"
        warnings.append("등고선이 매우 적거나 흐립니다. 선 대비와 끊김 여부를 확인해 주세요.")

    preview = original_rgb.copy()
    preview.thumbnail((1024, 1024), Image.Resampling.LANCZOS)
    preview_buffer = BytesIO()
    preview.save(preview_buffer, format="PNG", optimize=True)

    return PreparedTerrain(
        model_image=model_image,
        preview_png=preview_buffer.getvalue(),
        original_width=width,
        original_height=height,
        analysis_width=analysis_size[0],
        analysis_height=analysis_size[1],
        quality_score=quality_score,
        quality_status=quality_status,
        quality_details={
            "dynamic_range": round(dynamic_range, 6),
            "contrast_std": round(contrast_std, 6),
            "edge_density": round(edge_density, 6),
            "original_pixels": width * height,
        },
        warnings=warnings,
    )


def _fit_size(width: int, height: int, maximum: int) -> tuple[int, int]:
    if max(width, height) <= maximum:
        return width, height
    ratio = maximum / max(width, height)
    return max(16, round(width * ratio)), max(16, round(height * ratio))


def _to_rgb_on_white(image: Image.Image) -> Image.Image:
    if "A" not in image.getbands():
        return image.convert("RGB")
    rgba = image.convert("RGBA")
    background = Image.new("RGBA", rgba.size, "white")
    return Image.alpha_composite(background, rgba).convert("RGB")


def _edge_density(image: np.ndarray) -> float:
    dx = np.abs(np.diff(image, axis=1))
    dy = np.abs(np.diff(image, axis=0))
    horizontal = float(np.mean(dx > 0.08)) if dx.size else 0.0
    vertical = float(np.mean(dy > 0.08)) if dy.size else 0.0
    return 0.5 * (horizontal + vertical)

