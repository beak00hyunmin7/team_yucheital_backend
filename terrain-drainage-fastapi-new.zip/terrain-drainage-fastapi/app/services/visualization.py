from __future__ import annotations

from io import BytesIO

import numpy as np
from PIL import Image, ImageDraw


def validate_drainage_map(values: np.ndarray) -> np.ndarray:
    array = np.asarray(values, dtype=np.float32)
    if array.ndim != 2 or min(array.shape) < 2:
        raise ValueError("AI drainage_map은 2차원 배열이어야 합니다.")
    if not np.all(np.isfinite(array)):
        raise ValueError("AI drainage_map에 NaN 또는 무한대가 포함되어 있습니다.")
    if float(array.min()) < 0.0 or float(array.max()) > 1.0:
        raise ValueError("AI drainage_map의 값 범위는 0~1이어야 합니다.")
    return array


def render_drainage_map(
    values: np.ndarray, *, output_size: tuple[int, int]
) -> bytes:
    output = BytesIO()
    _heatmap(validate_drainage_map(values), output_size).save(
        output, format="PNG", optimize=True
    )
    return output.getvalue()


def render_overlay(
    values: np.ndarray,
    *,
    drains: list[tuple[str, float, float]],
    output_size: tuple[int, int],
) -> bytes:
    canvas = _heatmap(validate_drainage_map(values), output_size)
    draw = ImageDraw.Draw(canvas)
    width, height = canvas.size
    radius = max(7, round(min(width, height) * 0.016))
    line_width = max(2, radius // 5)
    for label, x_normalized, y_normalized in drains:
        x = round(x_normalized * max(width - 1, 1))
        y = round(y_normalized * max(height - 1, 1))
        draw.ellipse(
            (x - radius, y - radius, x + radius, y + radius),
            fill=(255, 232, 35),
            outline=(190, 20, 20),
            width=line_width,
        )
        box = draw.textbbox((0, 0), label)
        draw.text(
            (x - (box[2] - box[0]) / 2, y - (box[3] - box[1]) / 2 - 1),
            label,
            fill=(20, 20, 20),
        )
    output = BytesIO()
    canvas.save(output, format="PNG", optimize=True)
    return output.getvalue()


def _heatmap(values: np.ndarray, output_size: tuple[int, int]) -> Image.Image:
    red = np.clip(2.2 * values - 0.25, 0.0, 1.0)
    green = np.clip(1.4 - np.abs(2.2 * values - 1.0), 0.0, 1.0)
    blue = np.clip(1.2 - 2.0 * values, 0.0, 1.0)
    rgb = (np.stack([red, green, blue], axis=-1) * 255).astype(np.uint8)
    return Image.fromarray(rgb, mode="RGB").resize(
        output_size, Image.Resampling.BILINEAR
    )

