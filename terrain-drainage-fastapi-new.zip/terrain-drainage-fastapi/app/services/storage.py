from __future__ import annotations

import hashlib
from dataclasses import dataclass
from io import BytesIO
from pathlib import Path

import numpy as np
from PIL import Image

from app.config import STORAGE_ROOT


@dataclass(frozen=True)
class StoredAsset:
    kind: str
    relative_path: str
    mime_type: str
    file_hash: str
    width: int
    height: int

    @property
    def url(self) -> str:
        return f"/files/{self.relative_path}"


_CONTENT_TYPE_SUFFIX = {
    "image/png": ".png",
    "image/jpeg": ".jpg",
    "image/webp": ".webp",
    "image/tiff": ".tiff",
}


def ensure_storage() -> None:
    (STORAGE_ROOT / "uploads").mkdir(parents=True, exist_ok=True)
    (STORAGE_ROOT / "results").mkdir(parents=True, exist_ok=True)


def save_upload_original(
    *, upload_id: str, data: bytes, content_type: str | None, width: int, height: int
) -> StoredAsset:
    suffix = _CONTENT_TYPE_SUFFIX.get(content_type or "", ".png")
    return _save_bytes(
        directory=STORAGE_ROOT / "uploads" / upload_id,
        filename=f"original{suffix}",
        kind="ORIGINAL_IMAGE",
        data=data,
        mime_type=content_type or "image/png",
        width=width,
        height=height,
    )


def save_upload_preview(*, upload_id: str, data: bytes) -> StoredAsset:
    return _save_png(
        directory=STORAGE_ROOT / "uploads" / upload_id,
        filename="preview.png",
        kind="PREVIEW_IMAGE",
        data=data,
    )


def save_result_png(
    *, result_id: str, filename: str, kind: str, data: bytes
) -> StoredAsset:
    return _save_png(
        directory=STORAGE_ROOT / "results" / result_id,
        filename=filename,
        kind=kind,
        data=data,
    )


def save_result_array(*, result_id: str, array: np.ndarray) -> StoredAsset:
    output = BytesIO()
    np.save(output, np.asarray(array, dtype=np.float32), allow_pickle=False)
    data = output.getvalue()
    height, width = array.shape
    return _save_bytes(
        directory=STORAGE_ROOT / "results" / result_id,
        filename="drainage_map.npy",
        kind="DRAINAGE_MAP_ARRAY",
        data=data,
        mime_type="application/octet-stream",
        width=width,
        height=height,
    )


def read_asset(relative_path: str) -> bytes:
    path = (STORAGE_ROOT / relative_path).resolve()
    if path != STORAGE_ROOT and STORAGE_ROOT not in path.parents:
        raise ValueError("잘못된 저장 경로입니다.")
    return path.read_bytes()


def read_array(relative_path: str) -> np.ndarray:
    return np.load(BytesIO(read_asset(relative_path)), allow_pickle=False)


def asset_url(relative_path: str) -> str:
    return f"/files/{relative_path}"


def _save_png(
    *, directory: Path, filename: str, kind: str, data: bytes
) -> StoredAsset:
    with Image.open(BytesIO(data)) as image:
        width, height = image.size
    return _save_bytes(
        directory=directory,
        filename=filename,
        kind=kind,
        data=data,
        mime_type="image/png",
        width=width,
        height=height,
    )


def _save_bytes(
    *,
    directory: Path,
    filename: str,
    kind: str,
    data: bytes,
    mime_type: str,
    width: int,
    height: int,
) -> StoredAsset:
    directory.mkdir(parents=True, exist_ok=True)
    path = directory / filename
    path.write_bytes(data)
    return StoredAsset(
        kind=kind,
        relative_path=path.relative_to(STORAGE_ROOT).as_posix(),
        mime_type=mime_type,
        file_hash=hashlib.sha256(data).hexdigest(),
        width=width,
        height=height,
    )

